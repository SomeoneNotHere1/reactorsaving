const router={
	move(field,i){
		let targ=floor[i]
		if(targ.texture=='router.png'){
			if(targ.cooldown>=20){
				
				if(targ.routDirection=='1'){
					if(floor[i+20] !=null && floor[i+20].texture=='convUp.png' && floor[i+20].overlayTexture !=null){
						if(floor[i-1] !=null && floor[i-1].overlayTexture==null){
							floor[i-1].overlayTexture=floor[i+20].overlayTexture
							floor[i+20].overlayTexture=null
							targ.routDirection='2'
						}
					}
				}
				if(targ.routDirection=='2'){
					if(floor[i+20] !=null && floor[i+20].texture=='convUp.png' && floor[i+20].overlayTexture !=null){
						if(floor[i+1] !=null && floor[i+1].overlayTexture==null){
							floor[i+1].overlayTexture=floor[i+20].overlayTexture
							floor[i+20].overlayTexture=null
							targ.routDirection='1'
						}
					}
				}
			}
			else{
				targ.cooldown++	
			}
			
		}		
	},
	moveL(field,i){
		let targ=floor[i]
		if(targ.texture=='routerLeft.png'){//---->
			if(targ.cooldown>=20){
				if(targ.routDirection=='1'){
					if(floor[i-1] !=null && floor[i-1].texture=='convRight.png' && floor[i-1].overlayTexture !=null){
						if(floor[i+20] !=null && floor[i+20].overlayTexture==null){
							floor[i+20].overlayTexture=floor[i-1].overlayTexture
							floor[i-1].overlayTexture=null
							targ.routDirection='2'
						}
					}
				}
				if(targ.routDirection=='2'){
					if(floor[i-1] !=null && floor[i-1].texture=='convRight.png' && floor[i-1].overlayTexture !=null){
						if(floor[i-20] !=null && floor[i-20].overlayTexture==null){
							floor[i-20].overlayTexture=floor[i-1].overlayTexture
							floor[i-1].overlayTexture=null
							targ.routDirection='1'
						}
					}
				}
			}
			else{
				targ.cooldown++	
			}
			
		}	
	},
	moveR(field,i){
		let targ=floor[i]
		
		if(targ.texture=='routerRight.png'){//---->
			if(targ.cooldown>=20){
				if(targ.routDirection=='1'){
					if(floor[i+1] !=null && floor[i+1].texture=='convLeft.png' && floor[i+1].overlayTexture !=null){
						if(floor[i+20] !=null && floor[i+20].overlayTexture==null){
							floor[i+20].overlayTexture=floor[i+1].overlayTexture
							floor[i+1].overlayTexture=null
							targ.routDirection='2'
						}
					}
				}
				if(targ.routDirection=='2'){
					if(floor[i+1] !=null && floor[i+1].texture=='convLeft.png' && floor[i+1].overlayTexture !=null){
						if(floor[i-20] !=null && floor[i-20].overlayTexture==null){
							floor[i-20].overlayTexture=floor[i+1].overlayTexture
							floor[i+1].overlayTexture=null
							targ.routDirection='1'
						}
					}
				}
			}
			else{
				targ.cooldown++	
			}
			
		}		
	},
	moveU(field,i){
		let targ=floor[i]
		
		if(targ.texture=='routerUp.png'){//---->
			if(targ.cooldown>=20){
				if(targ.routDirection=='1'){
					if(floor[i-20] !=null && floor[i-20].texture=='movything.png' && floor[i-20].overlayTexture !=null){
						if(floor[i+1] !=null && floor[i+1].overlayTexture==null){
							floor[i+1].overlayTexture=floor[i-20].overlayTexture
							floor[i-20].overlayTexture=null
							targ.routDirection='2'
						}
					}
				}
				if(targ.routDirection=='2'){
					if(floor[i-20] !=null && floor[i-20].texture=='movything.png' && floor[i-20].overlayTexture !=null){
						if(floor[i-1] !=null && floor[i-1].overlayTexture==null){
							floor[i-1].overlayTexture=floor[i-20].overlayTexture
							floor[i-20].overlayTexture=null
							targ.routDirection='1'
						}
					}
				}
			}
			else{
				targ.cooldown++	
			}
			
		}
	},
}





















/*
		
		
		

		
		
		



*/