const ESell={
	sell(floor,i){
		let targ=floor[i]
		if(targ.cooldown>=40){
			targ.cooldown=0
			if(floor[i-1].texture=='wire.png'){
				if(floor[i-1].overlayTexture=='electric.png'){
					gameInfo.money+=10	
					let thewire=floor[i-1]
					let gene=floor[thewire.itemsStored]
					gene.texture='floor.png'
					for (let p = 0, len = floor.length; p < len; p++) {
						if(floor[p].texture !=null && floor[p].overlayTexture != null){
							if(floor[p].texture.includes("wire") || floor[p].texture.includes("elec") || floor[p].overlayTexture.includes("elec")){
								floor[p].overlayTexture=null
								targ.itemsStored=0
							}
						}
					}
				}
			}
		}
		else{
			targ.cooldown++	
		}
	},
}