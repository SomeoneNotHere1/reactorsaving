const sell={
	sellIt(floor,tex,targ){
		/*if(tex=='elecGen.png' || tex=='electric.png' || tex=='electricAlt.png' || tex=='wireTurnDown.png' || tex=='wireTurnDown1.png' || tex=='wireTurnUp.png' || tex=='wireTurnUp1.png'){
			for (let i = 0, len = floor.length; i < len; i++) {
			if(floor[i].overlayTexture=='electric.png' || floor[i].overlayTexture=='electricAlt.png'){
				floor[i].overlayTexture=null
				}
			}
		}*/
		
		
		//tex is the texter of targ
		//targ is the currnt tile
		//floor is floor... what did you expect? OhHh ItS a PoRtAl To NarNiA aNd MaGiK sTuFf
		if(targ.texture=='elecGen.png'){
			for (let p = 0, len = floor.length; p < len; p++) {
					if(floor[p].texture !=null && floor[p].overlayTexture != null){
						if(floor[p].texture.includes("wire") || floor[p].texture.includes("elec") || floor[p].overlayTexture.includes("elec")){
							floor[p].overlayTexture=null
							targ.itemsStored=0
						}
					}
				}
		}
		try{
		if(targ.texture !=null && targ.overlayTexture != null){
			if(targ.texture=="elecGen.png" || targ.texture.includes("wire") || targ.overlayTexture.includes("elec")){
				for (let p = 0, len = floor.length; p < len; p++) {
					if(floor[p].texture !=null && floor[p].overlayTexture != null){
						if(floor[p].texture.includes("wire") || floor[p].texture.includes("elec") || floor[p].overlayTexture.includes("elec")){
							floor[p].overlayTexture=null
							targ.itemsStored=0
						}
					}
				}
			}
			/*if(tex=='elecGen.png'){
				for (let p = 0, len = floor.length; p < len; p++) {
					if(floor[p].texture !=null && floor[p].overlayTexture != null){
						if(floor[p].texture.includes("wire") || floor[p].texture.includes("elec") || floor[p].overlayTexture.includes("elec")){
							floor[p].overlayTexture=null
						}
					}
				}
			}*/
		}
		}
		catch(e){alert(e)}
		for (let i = 0, len = placeOptions.length; i < len; i++) {
			if(placeOptions[i].texture==targ.texture){
				let discount = placeOptions[i].price*0.8
				let final=placeOptions[i].price-discount
				gameInfo.money+=final
			}
		}
		targ.texture='floor.png'
		targ.overlayTexture=null
		targ.overlayUpgrade=null
		targ.itemsStored=0
	},
}