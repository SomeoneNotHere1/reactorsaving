const moving={
	checkFrontCONV(lis,id){
		if(lis[id+20].texture=='movything.png'){
			return true
		}
		else{
			return false
		}
	},
	checkFrontCONVFULL(lis,id){
		if(lis[id+20].texture=='moveitem1.png'){
			return true
		}
		else{
			return false
		}
	},
}
