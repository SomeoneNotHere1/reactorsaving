const wire={
	doWire(floor,i){
		let targ=floor[i]
		if(targ.texture=='wireTurnDown.png'){
			if(floor[i-1].texture != null && floor[i-1].overlayTexture=='electric.png'){
				targ.overlayTexture='electricBendDown.png'
			}
			if(floor[i+20].texture != null && floor[i+20].overlayTexture=='electricAlt.png'){
				targ.overlayTexture='electricBendDown.png'
			}
			if(targ.overlayTexture=='electricBendDown.png'){
				if(floor[i-1].texture=='wire.png'){
					floor[i-1].overlayTexture='electric.png'
				}
				if(floor[i+20].texture=='wireAlt.png'){
					floor[i+20].overlayTexture='electricAlt.png'
				}
			}
		}
		
		if(targ.texture=='wireTurnUp.png'){
			if(floor[i-1].texture != null && floor[i-1].overlayTexture=='electric.png'){
				targ.overlayTexture='electricBend.png'
			}
			if(floor[i-20].texture != null && floor[i-20].overlayTexture=='electricAlt.png'){
				targ.overlayTexture='electricBend.png'
			}
			if(targ.overlayTexture=='electricBend.png'){
				if(floor[i-1].texture=='wire.png'){
					floor[i-1].overlayTexture='electric.png'
				}
				if(floor[i-20].texture=='wireAlt.png'){
					floor[i-20].overlayTexture='electricAlt.png'
				}
			}
		}
		
		if(targ.texture=='wireTurnUp1.png'){
			if(floor[i+1].texture != null && floor[i+1].overlayTexture=='electric.png'){
				targ.overlayTexture='electricBend1.png'
			}
			if(floor[i-20].texture != null && floor[i-20].overlayTexture=='electricAlt.png'){
				targ.overlayTexture='electricBend1.png'
			}
			if(targ.overlayTexture=='electricBend1.png'){
				if(floor[i+1].texture=='wire.png'){
					floor[i+1].overlayTexture='electric.png'
				}
				if(floor[i-20].texture=='wireAlt.png'){
					floor[i-20].overlayTexture='electricAlt.png'
				}
			}
		}
		
		if(targ.texture=='wireTurnDown1.png'){
			if(floor[i+1].texture != null && floor[i+1].overlayTexture=='electric.png'){
				targ.overlayTexture='electricBendDown1.png'
			}
			if(floor[i+20].texture != null && floor[i+20].overlayTexture=='electricAlt.png'){
				targ.overlayTexture='electricBendDown1.png'
			}
			if(targ.overlayTexture=='electricBendDown1.png'){
				if(floor[i+1].texture=='wire.png'){
					floor[i+1].overlayTexture='electric.png'
				}
				if(floor[i+20].texture=='wireAlt.png'){
					floor[i+20].overlayTexture='electricAlt.png'
				}
			}
		}
	},
}